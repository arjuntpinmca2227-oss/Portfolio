<?php include 'includes/header.php'; ?>

    <main>
        <section id="hero" class="hero">
            <h1>Big Days</h1>
            <p>Making Your Special Moments Unforgettable</p>
            <a href="#contact" class="cta-button">Plan Your Event</a>
        </section>

        <section id="services" class="services">
            <h2>Our Services</h2>
            <div class="service-grid">
                <div class="service-card">
                    <div class="service-image">
                        <img src="https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&q=80" alt="Wedding Service">
                    </div>
                    <div class="service-content">
                        <h3><span class="service-icon"></span> Weddings</h3>
                        <p>Create your perfect day with our comprehensive wedding planning services.</p>
                    </div>
                </div>
                <div class="service-card">
                    <div class="service-image">
                        <img src="https://images.unsplash.com/photo-1544804066-d8c7ce0ae4cf?auto=format&fit=crop&q=80" alt="Baptism Service">
                    </div>
                    <div class="service-content">
                        <h3><span class="service-icon"></span> Baptisms</h3>
                        <p>Mark this sacred occasion with our specialized baptism celebration services.</p>
                    </div>
                </div>
                <div class="service-card">
                    <div class="service-image">
                        <img src="https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?auto=format&fit=crop&q=80" alt="Engagement Service">
                    </div>
                    <div class="service-content">
                        <h3><span class="service-icon"></span> Engagements</h3>
                        <p>Begin your journey to forever with our elegant engagement celebrations.</p>
                    </div>
                </div>
                <div class="service-card">
                    <div class="service-image">
                        <img src="https://www.istockphoto.com/photo/dining-table-on-a-terrace-at-sunset-with-people-in-the-background-gm2063455271-564087098" alt="Dinner Party Service">
                    </div>
                    <div class="service-content">
                        <h3><span class="service-icon"></span>Dinner Parties</h3>
                        <p>Celebrate special moments with our thoughtfully curated dinner party experiences.</p>
                    </div>
                </div>
            </div>
        </section>

        <section id="about" class="about">
            <h2>About Big Days</h2>
            <div class="about-content">
                <p>With over a decade of experience in event management, Big Days specializes in creating memorable celebrations that reflect your unique style and vision. Our dedicated team of professionals ensures every detail is perfect, allowing you to fully enjoy your special day.</p>
            </div>
        </section>

        <section id="contact" class="contact">
            <h2>Contact Us</h2>
            <?php if (!empty($errors)): ?>
                <div class="error-messages">
                    <?php foreach ($errors as $error): ?>
                        <p class="error"><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?php if (isset($success)): ?>
                <div class="success-message">
                    <p><?php echo htmlspecialchars($success); ?></p>
                </div>
            <?php endif; ?>
            <form action="contact.php" method="POST" class="contact-form">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="message">Message:</label>
                    <textarea id="message" name="message" required></textarea>
                </div>
                <button type="submit" class="submit-button">Send Message</button>
            </form>
            <div class="contact-grid">
                <div class="contact-item">
                    <div class="contact-icon">📞</div>
                    <h3>Phone</h3>
                    <p>+91 9895522430</p>
                </div>
                <div class="contact-item">
                    <div class="contact-icon">📧</div>
                    <h3>Email</h3>
                    <p>contact@bigdays.com</p>
                </div>
                <div class="contact-item">
                    <div class="contact-icon">📍</div>
                    <h3>Location</h3>
                    <p>123 Event Street, City, Country</p>
                </div>
            </div>
        </section>
    </main>

<?php include 'includes/footer.php'; ?>
