    <footer class="footer">
        <div class="footer-content">
            <div class="footer-logo">
                <span class="logo-icon">👥</span>
                <span class="logo-text">Big Days</span>
            </div>
            <p>&copy; <?php echo date('Y'); ?> Big Days Event Management. All rights reserved.</p>
        </div>
    </footer>
    <script src="assets/js/main.js"></script>
</body>
</html>
